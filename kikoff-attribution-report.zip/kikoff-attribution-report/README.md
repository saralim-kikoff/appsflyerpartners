# AppsFlyer Monthly Attribution Report

Automated monthly report that pulls AppsFlyer data, identifies fraud and flagged events, and sends a summary to Slack.

## What It Does

1. **Pulls 4 reports from AppsFlyer** (previous month):
   - In-App Events (iOS + Android)
   - Protect360 Fraud Events (iOS + Android)

2. **Applies custom flagging rules** to identify suspicious attribution:
   - Unauthorized view-through attribution (VTA from non-approved agencies)
   - VTA window exceeded (>6 hours for approved agencies)
   - CTA window exceeded (>7 days)

3. **Calculates Net Valid Events**:
   ```
   Net Valid = Delivered - Fraud - Flagged
   ```

4. **Generates Excel report** with tabs:
   - Summary (agency rollup with all metrics)
   - Delivered Events (all events by agency)
   - Fraud Events (P360 events by agency)
   - Flagged Events (rule violations by agency)

5. **Posts summary to Slack**

## Setup

### 1. Clone the Repository

```bash
git clone https://github.com/your-org/kikoff-attribution-report.git
cd kikoff-attribution-report
```

### 2. Configure GitHub Secrets

Go to your repo → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

| Secret Name | Description |
|-------------|-------------|
| `APPSFLYER_API_TOKEN` | Your AppsFlyer V2.0 API Token (from Security Center) |
| `SLACK_WEBHOOK_URL` | Slack Incoming Webhook URL |

### 3. Verify App IDs

The script is pre-configured for:
- iOS: `id1525159784`
- Android: `com.kikoff`

To change, edit `APP_IDS` in `src/attribution_report.py`.

### 4. Enable GitHub Actions

Actions should be enabled by default. The workflow runs automatically on the 2nd of each month at 9am UTC.

## Usage

### Automatic (Scheduled)

The report runs automatically on the **2nd of each month** for the previous month's data.

### Manual Trigger

1. Go to **Actions** tab in GitHub
2. Select **Monthly Attribution Report**
3. Click **Run workflow**
4. Optionally override date range
5. Click **Run workflow**

### Local Testing

```bash
# Install dependencies
pip install -r requirements.txt

# Set environment variables
export APPSFLYER_API_TOKEN="your_token_here"
export SLACK_WEBHOOK_URL="your_webhook_here"

# Run
python src/attribution_report.py
```

## Flagging Rules

| Rule | Condition |
|------|-----------|
| **Unauthorized VTA** | `touch_type = impression` AND `agency` NOT IN `[adperiomedia, globalwidemedia]` |
| **VTA Window Exceeded** | `touch_type = impression` AND `agency` IN `[adperiomedia, globalwidemedia]` AND `lookback > 6h` |
| **CTA Window Exceeded** | `touch_type = click` AND `lookback > 7 days` |

### Modifying Rules

Edit these variables in `src/attribution_report.py`:

```python
# Agencies authorized for view-through attribution
VTA_AUTHORIZED_AGENCIES = ["adperiomedia", "globalwidemedia"]

# Attribution window limits
VTA_WINDOW_HOURS = 6
CTA_WINDOW_DAYS = 7
```

## Output

### Excel Report

Generated file: `attribution_report_{month}_{year}.xlsx`

**Summary Tab:**
| Agency | Delivered | Fraud | Flagged | Net Valid | Fraud Rate % | Flag Rate % |
|--------|-----------|-------|---------|-----------|--------------|-------------|
| agency_a | 1,250 | 45 | 12 | 1,193 | 3.6% | 1.0% |
| agency_b | 890 | 120 | 8 | 762 | 13.5% | 0.9% |

### Slack Message

```
📊 Monthly Attribution Report — November 2024

Overall Totals
• Delivered Events: 15,234
• Fraud Events (P360): 1,245 (8.2%)
• Flagged Events: 342 (2.2%)
• Net Valid Events: 13,647

Top Agencies by Net Valid
• agency_a: 4,521 net valid / 5,000 delivered (8.5% fraud)
• agency_b: 3,200 net valid / 3,800 delivered (12.1% fraud)
...
```

## Troubleshooting

### API Errors

- **401 Unauthorized**: Check your `APPSFLYER_API_TOKEN` is correct
- **403 Forbidden**: Verify API access permissions in AppsFlyer
- **No data returned**: Confirm the event name matches exactly

### Slack Not Working

- Verify webhook URL is correct
- Check webhook hasn't been revoked
- Test webhook manually:
  ```bash
  curl -X POST -H 'Content-type: application/json' \
    --data '{"text":"Test message"}' \
    YOUR_WEBHOOK_URL
  ```

### Missing Columns

The script handles various AppsFlyer column naming conventions. If you see warnings about missing columns, check your raw data export settings in AppsFlyer.

## File Structure

```
kikoff-attribution-report/
├── .github/
│   └── workflows/
│       └── monthly_report.yml    # GitHub Actions workflow
├── src/
│   └── attribution_report.py     # Main script
├── requirements.txt              # Python dependencies
└── README.md                     # This file
```

## License

Internal use only.
